var fullW = $(window).width(); // screen.availWidth;
var fullH = $(window).height(); // screen.availHeight;

var dialog = {
	openFull:function(title, url, param) {
		this.params = param;
		dialog.init(title, url, fullW, fullH, 0, 0);
	},
	/// <param name="dialogTitle">对话框标题</param>
	/// <param name="iframeSrc">iframe嵌入页面地址</param>
	/// <param name="iframeWidth">iframe嵌入页面宽</param>
	/// <param name="iframeHeight">iframe嵌入页面高</param>
	/// <param name="top">上边距</param>
	/// <param name="left">左边距</param>
	init:function(dialogTitle, iframeSrc, iframeWidth, iframeHeight, top, left){
		//获取客户端页面宽高
		var paramsString = '';
		for(var prop in this.params){
			paramsString += " "+prop+"='"+this.params[prop]+"'";
		}
		// 遮罩弹出窗口层
		if(typeof($("#shadeLayer")[0]) == "undefined") {
			$("body").prepend(""
				+ '<style>'
				+ ' #shadeLayer {'
				+ '   border: 1px solid #eaeaea; z-index: 999; position: fixed; top: 0px; left: 0px; background-color: #ffffff; overflow: hidden; ' 
				+ ' }'
				+ '</style>'
				+ "<div id='shadeLayer' snavtitle='"+dialogTitle+"' "+paramsString+">"
				+ "  <iframe id='iframepage' src='"+iframeSrc+"' style='border: 0px; width:"+iframeWidth+"px; height:"+iframeHeight+"px;'></iframe>"
				+ "</div>");

			var _jd_shadow = $("#shadeLayer");
			_jd_shadow.css("width", iframeWidth + "px");
			_jd_shadow.css("height", iframeHeight + "px");
		}
		
	},
	close:function(){
		$('#shadeLayer', parent.document).remove();
	}
};