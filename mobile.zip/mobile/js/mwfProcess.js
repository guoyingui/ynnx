function getPhaseParams (objecttype, objectid){
	var params = {
			objecttype: objecttype,
			objectid: objectid,
			objectID: objectid,
			workItemID: objectid,
			flag: "phaseinfo",
			loadextramenu: 1,
			iid: objectid,
			eid: objecttype
		};
	Common.sendFormData("/project/bpm/process/uTFProcessAction.do?sdo=getPhaseParams", null, function(res){
		if(res && res.successProperty){
			params.phaseID = res.data.phaseid;
			params.parentphaseid = res.data.parentphaseid;
			params.projectID = res.data.projectid;
			params.phaseOrStep = res.data.phaseorstep;
			params.methodtemplateID = res.data.methodtemplateid;
			params.parentPhaseID = res.data.parentphaseid;
		}
	}, {objecttype: objecttype, objectid: objectid}, {async: false});
	return params
}
var EntitiesInfo = {
	0: {
		entityName: "项目群组",
		icon_s: "/project/images/icon_managerg.gif",
		icon_t: "open_managerG.gif",
		flowMenuItemId: 23,
		menuCfg: "pfinfos",
		getParams: function(objecttype, objectid){
			return {
				projectID: objectid,
				objectID: objecttype,
				workItemID: objectid,
				typeID: objecttype,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	1: {
		entityName: "项目",
		icon_s: "/project/images/icon/icon09.gif",
		icon_t: "open_manager.gif",
		flowMenuItemId: 27,
		menuCfg: "pjinfos",
		getParams: function(objecttype, objectid){
			return {
				projectID: objectid,
				objectID: objecttype,
				workItemID: objectid,
				typeID: objecttype,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	9: {
		entityName: "合同",
		icon_s: "/project/images/icon_contract.gif",
		icon_t: "open_contract.gif",
		flowMenuItemId: 23,
		menuCfg: "contractBar",
		getParams: function(objecttype, objectid){
			return {
				contractID: objectid,
				objectID: objecttype,
				workItemID: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	45: {
		entityName: "预算明细",
		icon_s: "/project/images/icon_budgetManager.gif",
		icon_t: "open_budgetManager.gif",
		flowMenuItemId: 22,
		menuCfg: "budgetManager",
		getParams: function(objecttype, objectid){
			return {
				objectID: objecttype,
				workItemID: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	46: {
		entityName: "费用明细",
		icon_s: "/project/images/icon_feeManager.gif",
		icon_t: "open_feeManager.gif",
		flowMenuItemId: 22,
		menuCfg: "feeManager",
		getParams: function(objecttype, objectid){
			return {
				objectID: objecttype,
				workItemID: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	21: {
		entityName: "高层计划-阶段",
		icon_s: "/project/images/icon_phase.gif",
		icon_t: "open_phase.gif",
		flowMenuItemId: 23,
		menuCfg: "phasebar",
		getParams: getPhaseParams
	},
	23: {
		entityName: "高层计划-里程碑",
		icon_s: "/project/images/icon_milestone.gif",
		icon_t: "open_milestone.gif",
		flowMenuItemId: 22,
		menuCfg: "milestonebar",
		getParams: getPhaseParams
	},
	22: {
		entityName: "高层计划-交付物",
		icon_s: "/project/images/icon_object.gif",
		icon_t: "open_object.gif",
		flowMenuItemId: 23,
		menuCfg: "deliverablesbar",
		getParams: getPhaseParams
	},
	24: {
		entityName: "高层计划-活动",
		icon_s: "/project/images/icon_gcjh.gif",
		icon_t: "open_gcjh.gif",
		flowMenuItemId: 22,
		menuCfg: "taskbar",
		getParams: getPhaseParams
	},
	41: {
		entityName: "文档",
		icon_s: "/project/images/icon_file.gif",
		icon_t: "open_wdzy.gif",
		flowMenuItemId: 25,
		menuCfg: "docInfo",
		getParams: function(objecttype, objectid){
			return {
				docId: objectid,
				objectID: objecttype,
				workItemID: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	33: {
		entityName: "WBS元素",
		icon_s: "/project/images/icon_edit.gif",
		icon_t: "open_taskgz.gif",
		flowMenuItemId: 27,
		menuCfg: "wbs_task_2nd",
		getParams: function(objecttype, objectid){
			var projectID = null;
			Common.sendFormData("/project/bpm/process/uTFProcessAction.do?sdo=getWBSParams", null, function(res){
				if(res && res.successProperty){
					projectID = res.data.projectid;
				}
			}, {objecttype: objecttype, objectid: objectid}, {async: false});
			return {
				wbsObjectID: objecttype,
				objectID: objecttype,
				projectID: projectID,
				workItemID: objectid,
				detailobjectid: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	},
	2000: {
		entityName: "实体",
		icon_s: "/project/images/icon_edit.gif",
		icon_t: "open_edit.gif",
		flowMenuItemId: 22,
		menuCfg: "workItem4",
		getParams: function(objecttype, objectid){
			return {
				objectID: objecttype,
				workItemID: objectid,
				loadextramenu: 1,
				iid: objectid,
				eid: objecttype
			};
		}
	}
};
function fixObjectType(objecttype){
	if(",31,32,33,34,".indexOf(","+objecttype+",")>=0){
		return 33;
	}
}
function openObject(objecttype, objectid, objectName, flowInsId, stepInsId){
	var entityInfo;
	var projecturl;
	if(",31,32,33,34,".indexOf(","+objecttype+",")>=0){
		objecttype = 33;
		entityInfo = EntitiesInfo[objecttype];
		Common.WBS.open2ndWin('1',objecttype, objectid, "", $.extend({channel: "mainPage"},entityInfo.getParams(objecttype, objectid)), entityInfo.flowMenuItemId);
		return;
	}else if(objecttype>=2000 && objecttype<=2999){
		entityInfo = EntitiesInfo[2000];
	}else if(objecttype>=211 && objecttype<=215){
		var icon = '';
		if(objecttype == 211){
			icon = '52R1.png';
		}else if(objecttype == 212){
			icon = '52R2.png';
		}else if(objecttype == 213){
			icon = '52R3.png';
		}else if(objecttype == 214){
			icon = '52R4.png';
		}else{
			icon = '52R5.png';
		}
		var url1='/project/vn/mywork/reqTreeAction.do?method=getReqstoreID';
		var id = objectid;
		var dataObj = new Object();
		dataObj.id = id;
		dataObj.objectID =objecttype;
		Common.sendFormData(url1,undefined,function(res){
			tempStr="demandinfo2";
			var url = "/project/vframe/openWindowAction.do?winTitle=需求";
			url += "&topFrame=objTitle=需求;objName="+objectName+";objType=信息;objIcon="+icon;	
			url += "&leftFrame=fileName="+tempStr+";selectItemID=28;objectID="+objecttype+";projectID=;workItemID="+ id+";loadextramenu=1;display=1;start=1;limit=50;rtype=1;iid="+id+";eid="+objecttype;
			url += "&rightFrame=/project/vn/manager/demandInfoToolbarAction.do?objectID="+objecttype+";projectID=;workItemID=" + id+";libraryID="+res.reqstoreid+";reqId="+id;
			if(flowInsId){
				url += ";channel=mainPage;fromType=mywork;flowid="+flowInsId+";stepid="+(stepInsId || -1);
			}
			Common.showWin(url);
		},dataObj);
		return;
	}else if(objecttype == 221){
		var id = objectid;
		tempStr="vnWorkItem4newchange2";
		var url = "/project/vframe/openWindowAction.do?winTitle=变更请求"
		url += "&topFrame=objTitle=变更请求;objName="+objectName+";objType=信息;objIcon=52bgqq.gif";	
		url += "&leftFrame=fileName="+tempStr+";selectItemID=24;objectID="+objecttype+";projectID=;workItemID="+ id+";loadextramenu=1;display=1;start=1;limit=50;rtype=1;iid="+id+";eid="+objecttype;
		url += "&rightFrame=/project/vn/change/workItemInfoToolbarAction.do?objectID="+objecttype+";projectID=;workItemID=" + id;
		if(flowInsId){
			url += ";channel=mainPage;fromType=mywork;flowid="+flowInsId+";stepid="+(stepInsId || -1);
		}
		Common.showWin(url);
		return;
	}else{
		entityInfo = EntitiesInfo[objecttype];
	}
	var params = $.extend({
		selectItemID: entityInfo.flowMenuItemId
	},entityInfo.getParams(objecttype, objectid));
	if(flowInsId){
		params = $.extend(params, {
			channel: "mainPage",
			fromType: "mywork",
			flowid: flowInsId,
			stepid: stepInsId || -1
		});
	}
	
	var url = '/project/vocation/workItem/tabs.jsp';
	if(objecttype==9){
		url = '/project/finance/contractTabs.jsp';
	}else if(objecttype==1 || objecttype==0){
		projecturl = "/project/vframe/openWindowAction.do?winTitle="+entityInfo.entityName;
		projecturl += "&topFrame=objTitle="+entityInfo.entityName+";objName="+objectName+";objType=基本信息;objIcon="+entityInfo.icon_s;
		projecturl += "&leftFrame=fileName="+entityInfo.menuCfg+";projectID="+entityInfo.getParams(objecttype, objectid).projectID
		        +";selectItemID=20;objectID="+entityInfo.getParams(objecttype, objectid).objectID
		        +";workItemID="+entityInfo.getParams(objecttype, objectid).projectID
		        +";loadextramenu=1;display=1;start=1;limit=50;rtype=1;iid="+entityInfo.getParams(objecttype, objectid).projectID
		        +";eid="+entityInfo.getParams(objecttype, objectid).objectID;
		projecturl += "&rightFrame=/project/wbs/projectManageMenuAction.do?projectID="+entityInfo.getParams(objecttype, objectid).projectID+";projectName=;typeID="+entityInfo.getParams(objecttype, objectid).objectID+";parentID=0";
		projecturl += "&projectid="+entityInfo.getParams(objecttype, objectid).projectID+"&stype=viewpj";
	}
		url += '?fileName='+entityInfo.menuCfg;
		url += '&' + Common.concatParams(params, "&");
	var map = {};
	map["fromType"] = 'myflow';

	if(objecttype==1 || objecttype==0){
		if(parent.parent.location.href.indexOf("dashboard.jsp")!=-1){
			parent.parent.parent.parent.dialog.openFull(entityInfo.entityName+'-->'+objectName, projecturl, map);
		}else{
			parent.parent.dialog.openFull(entityInfo.entityName+'-->'+objectName, projecturl, map);
		}
	}
	else if (parent.parent.location.href.indexOf("dashboard.jsp")!=-1) {
		parent.parent.parent.parent.dialog.openEdit(entityInfo.entityName+'-->'+objectName, url, map);
	}
	else if (parent.parent.location.href.indexOf("titleAction")!=-1) {
		parent.parent.parent.parent.dialog.openEdit(entityInfo.entityName+'-->'+objectName, url, map);
	}
	else {
		parent.parent.dialog.openEdit(entityInfo.entityName+'-->'+objectName, url, map);
	}
	//parent.parent.dialog.openEdit('<%=titleText%>-->'+workItemName, url);
	//
	/*
	Common.showWin(Common.getObjUrl({
		objTitle: entityInfo.entityName,
		objName: objectName,
		objIcon: entityInfo.icon_t,
		fileName: entityInfo.menuCfg,
		params: params,
		winTitle: objectName
	}));
	*/
}

var StepUserUtil = {	
	initGrid: function (width, height, renderTo, objecttype, objectid, flowInsId){
		this.objecttype = objecttype;
		this.objectid = objectid;
		this.flowInsId = flowInsId;
		var cfg = {
			width: width,
			height: height,
			renderTo: renderTo,
			autoExpandColumn: 'userid',
			column:[
		    	{header: "流程步骤", id:"stepname", width:140, altField: "stepname"},
		    	{header: "活动类型", id:"steptype", width:58, reneerer: function(value,metadata,record,rowIndex){
		    		var str = "";
		    		switch (value){
		    		case 4 :
		    			str = '审批';
		    			break;
		    		case 6 :
		    			str = '评审';
		    			break;
		    		case 8 :
		    			str = '处理'
		    			break;
		    		}
		    		return str;
		    	}},
		    	{header: "处理模式", id:"usermodestr", width:58},
		    	{header: "", id:"mustinput", width:8,renderer:function(v){
		    		return v==1?'<span style="color:red;">*</span>':'';
		    		
		    	}},
		    	{header: "处理人", id:"userid", width:130, renderer: function(value,metadata,record,rowIndex){
		    		metadata.classNames = "WF_stepUser";
		    		var lickFn = 'onclick="StepUserUtil.searchUser('+rowIndex+');"';
		    		if(record.fixflag==1){
		    			lickFn = "";
		    		}
		    		var inputClass = "#ffffff"; 
		    		if(record.usermode==1 || record.usermode==4){
//		    			inputClass = " inputMust";
						inputClass = "#f8ecd4";
		    		}
		    		
		    		var res = '<table width="100%" class="fixtab" cellspacing="0" cellpadding="0"><tr>'
		    				+'<td class="inputTd">'		
			    				+'<input id="step_user_'+record.stepid+'" type="hidden" value="'+(record.userid||"")+'"/>'
		    					+'<input id="step_user_name_'+record.stepid+'" class="'+inputClass+'" type="text" value="'+(record.username||"")+'" readonly="readonly" '+lickFn+' style="background:url(/project/vframe/images/other/addPerson.gif) center right no-repeat; background-color: '+inputClass+'; width: 99.5%;"/></td>'
	    					/*+'<td width="22" align="right" height="16">'
			    				+'<img src="/project/vframe/images/btnIcon/btn_icon_find.gif" '+lickFn+'/></td>'*/
			    		+'<td width="5"></td></tr></table>';
		    		if(record.mustinput==1){
		    			// StepUserUtil.mustinputIds.push({code:record.stepcode,id:'step_user_'+record.stepid,name:'step_user_name_'+record.stepid});
		    		}
		    		return res;
		    	}}
			]
		};
		this.grid = new VList(cfg);
		//return this.grid;
		return ' <div class="label"><img src="../img/release@3x.png"/>处理人2</div> <div class="input"> <input type="text" placeholder="必填项" id="notice_title"></div>';
	},
	hasntProcessSteps:[],//{code:1,userIds:'1,2,3',userNames:'a,b,c'}
	cacheNextSteps:function(a){
		if(a&&a.length>0){
			var nc=this.nextStepsCache={};
			for(var i=0,l=a.length;i<l;i++){
				var cur=a[i];
				nc[cur.stepcode]={code:cur.stepcode,id:cur.stepid,userids:cur.userid,usernames:cur.username,srcp:cur};
			}
		}
	},
	setSingleStepUser:function(o){
		var nc=this.nextStepsCache,cur;
		if(cur=nc[o.code]){
			document.getElementById('step_user_'+cur.id).value=cur.srcp.userid=o.userIds||'';
			document.getElementById('step_user_name_'+cur.id).value=cur.srcp.username=o.userNames||'';
		}
		
	},
	isRunningSetUser:false,
	doSetStepUser:function(){
		if(StepUserUtil.nextStepsCache){
			var a=StepUserUtil.hasntProcessSteps;
			for(var i=0,l=a.length;i<l;i++){
				var cur=a[i];
				StepUserUtil.setSingleStepUser(cur);
			}
			StepUserUtil.hasntProcessSteps=[];
			StepUserUtil.isRunningSetUser=false;
		}else{
			setTimeout(StepUserUtil.doSetStepUser,100);

			
		}
	},
	saveUsertoServer:function(a){
		var steps=[];
		for(var i=0,l=a.length;i<l;i++){
			var cur=a[i];
			steps.push('{"code":"'+cur.code+'","userIds":"'+cur.userIds+'"}');
		}
		steps="["+steps.join(",")+"]";
		steps=encodeURIComponent(steps);
		var dataObj = new Object();
		dataObj.flowid = flowid;
		dataObj.flowexpid = flowexpid;
		dataObj.stepid = stepid;
		dataObj.stepexpid = stepexpid;
		dataObj.objectid = objectID;
		dataObj.objecttype = objecttype;
		dataObj.formtype = formtype;
		dataObj.formid = formid;
		dataObj.fid =fid;
		dataObj.stepUsers=steps;
		Common.sendFormData('/project/bpm/form/cfgFormAction.do?method=setStepUserTemp',undefined,function(res){
		   //do something
			
				
		},dataObj);
	},
	setStepUser:function(a){
		StepUserUtil.saveUsertoServer(a);
		var me=this,steps=me.hasntProcessSteps||[];
		for(var i=0,l=a.length;i<l;i++){
			steps.push(a[i]);
		}
		this.hasntProcessSteps=steps;
		
		if(me.isRunningSetUser){
			
		}else{
			me.isRunningSetUser=true;
			StepUserUtil.doSetStepUser();
		}
		
		
		
	},
	mustinputIds:[],
	jumpedIds:{},
	hasntProcessIds:{ids:[],count:0},
	hideSigleStep:function(cur){
		var code=cur.id,op=cur.op,step=document.getElementById(code+'_user_tr');
		if(step){
			if(op=='hide'){
				step.style.display='none';
			}else{
				step.style.display='block';
			}
			
			return true;
		}else{
			return false;
		}
	},
	isRunningHide:false,
	hideSteps:function(){
		var hasntProcessIds=StepUserUtil.hasntProcessIds,idCache=hasntProcessIds.ids,jumpedIds=StepUserUtil.jumpedIds,newCache=[];
		for(var i=0,l=idCache.length;i<l;i++){
			var cur=idCache[i];
			if(StepUserUtil.hideSigleStep(cur)){
				hasntProcessIds.count--;
			}else{
				newCache.push(cur);
			}
		}
		StepUserUtil.hasntProcessIds={ids:newCache,count:newCache.length}
		if(hasntProcessIds.count>0){
			setTimeout(StepUserUtil.hideSteps,100);
		}else{
			StepUserUtil.isRunningHide=false;
		}
	},
	opStep:function(sCode,opType){
		var me=this,jumpedIds=me.jumpedIds,hasntProcessIds=me.hasntProcessIds,idCache=hasntProcessIds.ids,sCode=sCode.split(',');
		for(var i=0,l=sCode.length;i<l;i++){
			var cur=sCode[i];
			jumpedIds[cur]=(opType=='hide'?true:false);
			idCache.push({id:cur,op:opType});
			hasntProcessIds.count++;
		}
		if(me.isRunningHide){
			
		}else{
			me.isRunningHide=true;
			StepUserUtil.hideSteps();
		}
		
	},
	showStep:function(sCode){
		StepUserUtil.opStep(sCode,'show');
	},
	hideStep:function(sCode){
		StepUserUtil.opStep(sCode,'hide');
	},
	checkMustInputUser:function(){
		var ids=this.mustinputIds,hasEmpty=false;
		if(ids.length>0){
			for(var i=0,l=ids.length;i<l;i++){
				cur=ids[i];
				if(!document.getElementById(cur.id).value){
					if(this.jumpedIds[cur.code]){
						;
					}else{
						//document.getElementById(cur.name).style.border='1px solid red';
						document.getElementById(cur.name).style='border: 0px; width: 100%;height: 100%;background-color: #ffffff;outline: none;';
						hasEmpty=true;
					}
					
				}else{
					//  new TipBox('3333');
					// document.getElementById(cur.name).style.border='1px solid #A1A1A1';
					//document.getElementById(cur.name).style.border='1px solid red';
				}
			}
		}
		return hasEmpty;
	},
	searchUser: function (rowIndex){		
		var record = this.grid.getByIndex(rowIndex);
		if(record.fixflag==1){
			return;
		}
		var stepid = record.stepid;
		var initusertype = record.initusertype;
		var $idNode = $("#step_user_"+stepid);
		var $nameNode = $("#step_user_name_"+stepid);
		if(initusertype==0){
			var users = parent.parent.parent.Search.user({
				userID: $idNode.val(),
				userName: $nameNode.val(),
				componentID: 20501,
				multiple: true,
				search:2,
				name:stepid
			});
			if(users){
				$idNode.val(users.userID);
				$nameNode.val(users.userName);
			}
		}else if(initusertype==1){//特定人员
			this.searchExistsUser($idNode, $nameNode, record.abailableuser);
		}else if(initusertype==2){//特定角色
			this.searchRoleUser($idNode, $nameNode, record.abailableuser);
		}else if(initusertype==4){//特定组
			this.searchGroupUser($idNode, $nameNode, record.abailableuser);
		}
		this.checkMustInputUser();
	},
	searchExistsUser: function($idNode, $nameNode, userArr){
		if(!this.existsUserInited){
			this.existsUserPicker = new ExistsUserPicker({
				id: "existsUser"
			});
			var me = this;
			this.existsUserPicker.callBack = function(){
				if(this.returnValue){
					var userArr = this.returnValue;
					var idStr = "", nameStr = "";
					for(var i=0, len=userArr.length; i<len; i++){
						idStr += userArr[i].userid+",";
						nameStr += userArr[i].username+",";
					}
					if(idStr!="")idStr = idStr.substring(0, idStr.length-1);
					if(nameStr!="")nameStr = nameStr.substring(0, nameStr.length-1);
					this.context.$idNode.val(idStr);
					this.context.$nameNode.val(nameStr);
				}
			}
			this.existsUserInited = true;
		}
		this.existsUserPicker.readUsers(userArr);
		this.existsUserPicker.context = {
			$idNode: $idNode, 
			$nameNode: $nameNode
		};
		this.existsUserPicker.show($nameNode[0], $idNode.val()?$idNode.val().split(","):[]);
	},
	searchGroupUser: function($idNode, $nameNode, userArr){
		if(!this.groupUserInited){
			this.groupUserPicker = new GroupUserPicker({
				id: "groupUser"
			});
			var me = this;
			this.groupUserPicker.callBack = function(){
				if(this.returnValue){
					var userArr = this.returnValue;
					var idStr = "", nameStr = "";
					for(var i=0, len=userArr.length; i<len; i++){
						idStr += userArr[i].userid+",";
						nameStr += userArr[i].username+",";
					}
					if(idStr!="")idStr = idStr.substring(0, idStr.length-1);
					if(nameStr!="")nameStr = nameStr.substring(0, nameStr.length-1);
					this.context.$idNode.val(idStr);
					this.context.$nameNode.val(nameStr);
				}
			}
			this.groupUserInited = true;
		}
		this.groupUserPicker.readUsers(userArr);
		this.groupUserPicker.context = {
				$idNode: $idNode, 
				$nameNode: $nameNode
		};
		this.groupUserPicker.show($nameNode[0], $idNode.val()?$idNode.val().split(","):[]);
	},
	searchRoleUser: function($idNode, $nameNode, userArr){
		var me = this;
		if(!this.roleUserInited){
			this.roleUserPicker = new RoleUserPicker({
				id: "roleUser"
			});
			this.roleUserPicker.callBack = function(){
				if(this.returnValue){
					var userArr = this.returnValue;
					var idStr = "", nameStr = "";
					for(var i=0, len=userArr.length; i<len; i++){
						idStr += userArr[i].userid+",";
						nameStr += userArr[i].username+",";
					}
					if(idStr!="")idStr = idStr.substring(0, idStr.length-1);
					if(nameStr!="")nameStr = nameStr.substring(0, nameStr.length-1);
					this.context.$idNode.val(idStr);
					this.context.$nameNode.val(nameStr);
				}
			}
			this.roleUserInited = true;
		}
		this.roleUserPicker.readUsers(userArr);
		this.roleUserPicker.context = {
			$idNode: $idNode, 
			$nameNode: $nameNode
		};
		this.roleUserPicker.show($nameNode[0], $idNode.val()?$idNode.val().split(","):[]);
	},
	getStepUsers: function(checkInput){
		checkInput = checkInput!==false;
		checkInput = false;
		var arr = [];
		var dataArr = this.grid.data.data,
			record;
		for(var i=0, len=dataArr.length; i<len; i++){
			record = dataArr[i];
			var identity = record.stepid;
			var userid = $("#step_user_"+identity).val();
			if(checkInput && userid=="" && (record.usermode==1 || record.usermode==4)){
				new TipBox("步骤“"+record.stepname+"”必须设置处理人！");
				return false;
//			}else if(userid=="" ){
//				continue;
			}
			arr.push({
				stepid: identity, 
				usermode: record.usermode,
				userid: userid
			});
		}
		return arr;
	}
}
var ExistsUserPicker = function(cfg){
	this.init(cfg);
};
$.extend(ExistsUserPicker.prototype, {
	init : function(cfg){
		$.extend(this, cfg);
		this.createDom();
//		this.readUsers(cfg.userArr);
	},
	createDom: function(){
		this.$dom = $('<div class="pickerPanel hideNode">'
			+'<div id="pickerGridDiv_'+this.id+'" class="pickerGridDiv"></div>'
			+'<div class="pickerBtn">'
				+'<input id="pickerOkBtn_'+this.id+'" type="button" value="确定" />'
				+'<input id="pickerCancelBtn_'+this.id+'" type="button" value="取消" />'
			+'</div>'
		+'</div>');
		this.$okBtn = this.$dom.find('#pickerOkBtn_'+this.id);
		this.$cancelBtn = this.$dom.find('#pickerCancelBtn_'+this.id);
		this.$okBtn.bind("click", function(){
			me.ok()
		})
		this.$cancelBtn.bind("click", function(){
			me.hide()
		})
		this.$dom.bind("mousedown", function(event){
			return false;
		})
		document.body.appendChild(this.$dom[0]);
		this.createGrid();
		var me = this;
		bindEvent(document.body, "mousedown", function(){
			me.hide();
		})
	},
	createGrid: function(){
		var id = this.id;
		this.grid = new VList({
			width: "100%",
			height: 135,
			renderTo: "pickerGridDiv_"+id,
			selector:{type:'checkbox',name:'userid',valueName:'userid'},
			column:[
		    	{header: "用户名称", id:"username"}
			]
		});
	},
	readUsers: function(userArr){
		this.grid.readData(userArr);
	},
	resize: function(){
		this.grid.resize();
	},
	show: function(node, idArr){
		var $node = $(node);
		$node.offsetParent().append(this.$dom);
		var nodeOffset = $node.offset();
		var nodeSize = {
			width: $node.width(),
			height: $node.height()
		};
		var winSize = {
			width : (window.innerWidth || document.documentElement.clientWidth) || document.body.clientWidth,
			height : (window.innerHeight || document.documentElement.clientHeight) || document.body.clientHeight
		};
		var scrollOffset = Fns.scrollOffset();
		var pos = {
			top : nodeOffset.top + nodeSize.height + 2,
			left : nodeOffset.left
		};
		var domSize = {width: this.$dom.width()+10, height: this.$dom.height()+10};
		if(pos.top - scrollOffset.y + domSize.height + 20 > winSize.height){
			//pos.top = winSize.height - domSize.height - 20 + scrollOffset.y;
			pos.top=nodeOffset.top- domSize.height;
		}
		if(pos.left - scrollOffset.x + domSize.width + 20 > winSize.width){
			pos.left = winSize.width - domSize.width - 20 + scrollOffset.x;
		}
		this.$dom.css(pos);
		this.$dom.show();
		this.resize();
		if(idArr){
			this.selectByIds(idArr);
		}
	},
	hide: function(){
		this.$dom.hide();
		if(this.callBack){
			this.callBack();
		}
	},
	ok: function(){
		this.returnValue = this.grid.getSelected();
		this.hide();
	},
	selectByIds: function(idArr){
		this.grid.selectByIds("userid", idArr);
	}
});
var RoleUserPicker = function(cfg){
	this.init(cfg);
};
$.extend(RoleUserPicker.prototype, ExistsUserPicker.prototype, {
	createGrid: function(){
		var id = this.id;
		this.grid = new VList({
			width: "100%",
			height: 135,
			renderTo: "pickerGridDiv_"+id,
			selector:{type:'checkbox',name:'userid',valueName:'userid'},
			column:[
		        {header: "角色名称", id:"rolename", width: 80},
		    	{header: "用户名称", id:"username"}
			]
		});
	}
});
var GroupUserPicker = function(cfg){
	this.init(cfg);
};
$.extend(GroupUserPicker.prototype, ExistsUserPicker.prototype);
function setReturnValue(objj){
	$("#step_user_"+objj.fieldID).val(objj.userID);
	$("#step_user_name_"+objj.fieldID).val(objj.userName);
}