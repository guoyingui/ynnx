//var _table = '<table id="{#tableID}" class="form_body_frame_table" style="border:0px #a2a4b0 solid; {#display};" width="100%" border="0" cellpadding="0" cellspacing="0">'
//+'<col/><col width="1"/><col/>'
//+'{#tr}</table><div style="height:5px;"></div>';
//var _table ='<ul>{#tr}</ul>';
//var _tr = "<li>{#td}</li>";
var _table ='{#tr}';
var _tr ='<div class="line">{#td}</div>';
var _blank_td = "";
var _double_td = '<td>{#content1}</td><td></td><td>{#content2}</td><td width="30"></td>';
var _single_td = '{#content}';
var _lable = '<div class="{#class}">{#img}{#lable}</div>{#mustLable}';
var _remark_lable = '<th class="active_th" nowrap onclick="Common.showText(this,\'remark\')"><div class="lableText">{#lable}</div><div class="lableClose"></div>{#mustLable}</th>';
var _mustLable = '' ;//'<div class="lableMust"></div>';
//var _fieldTable = '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr>{#content}</tr></table>';

var _fieldTable = '{#content}';
 
//var _input = '<td class="textCell"><input id="{#id}" name="{#name}" hidID="{#hidID}" number="{#number}" type="text" class="{#class}"  value="{#value}" {#cstProperty} {#readonly} onclick="{#click}" style="background:url({#icon}) center right no-repeat; background-color: {#color}; width: 97%;" /></td>';
var _input = ' <div class="input"><input id="{#id}" name="{#name}" hidID="{#hidID}" number="{#number}"  type="text"  value="{#value}" class="{#class}" style="{#style}"  {#readonly}  onclick="{#click}" /></div>';
var _searchInput = '<td width="17" align="right"><img src="{#icon}" width="16" height="16" onclick="{#click}"/></td>';
var _dateInput = '<td width="17" align="right"><img src="/project/images/icon/icon50.gif" width="16" height="16" onclick="{#click}"/></td>';

var _select = '<div class="input"><select id="{#id}" class="{#class}" style="{#style}" {#cstProperty} {#disabled}>{#option}</select></div>';
var _selectList = '<td class="otherCell"><select id="{#id}" style="height:50px" class="inputSelect" size="{#size}" {#multiple} {#cstProperty} {#disabled}>{#option}</select></td>';
var _selectOption = '<option value="{#value}" {#selected}>{#text}</option>';
var _radio = '<div class="inputRC">{#radiobox}</div>';
var _radiobox = '<label class="labelRadio"><input type="radio" name="{#name}" value="{#value}" style="{#style}" class="inputRadio"   {#cstProperty} {#checked} {#disabled}/><span class="inputRadioInput"></span>{#text}&nbsp;</label>';
var _checkbox = '<label class="labelRadio"><input type="checkbox" name="{#name}" value="{#value}" style="{#style}" class="inputRadio"  {#cstProperty} {#checked} {#disabled}/><span class="inputCheckbox inputRadioInput"></span>{#text}&nbsp;</label>';
//var _textarae = '<div class="input"><textarea id="{#id}" rows="1"  {#cstProperty} {#readonly}>{#value}</textarea></div>';
//var _textarae = ' <div class="input"><input id="{#id}" name="{#name}" hidID="{#hidID}" number="{#number}"  type="text"  value="{#value}"  {#readonly} /></div>';
var _textarae = ' <div class="inputRC"><textarea id="{#id}" name="{#name}" hidID="{#hidID}" number="{#number}" rows="{#rows}" name="audittext"   {#readonly}>{#value}</textarea></div>';
var _richText = '<div id="{#id}" class="input"><a href="#" onclick="{#click}">点击查看</a></div>';
var _frame = '<td class="textCell"><iframe id="frame_{#id}" width="100%" height="100%" frameborder="0" src="{#src}" style="border:1px #a2a4b0 solid; margin-left: 25px; margin-top: 5px;"></iframe></td>';
var _remark_textarae = '<td class="textCell"><div class="formlink" style="{#display}"><a href="#" onclick="updatePerson(3,\'remark\')">添加备注</a></div><textarea id="{#id}" rows="{#rows}" class="inputTextareaRead" style="cursor:default;overflow-y:hidden" {#cstProperty} {#readonly}>{#value}</textarea></td>';

var _link_field = '<div class="input"><a href="#" onclick="{#click}">{#text}</a></div>';
var _link = '<div class="formlink"><a href="#" onclick="#click">{#text}</a></div>';

var _group = '<p class="formNodeTitle">{#title}<i class=" mformgroup_icon_visible"></i></p>';

var _cstProperty = ' mustInput = "{#mustInput}" propertyText = "{#propertyText}" propertyType="{#propertyType}" systype="{#systype}"';
var _file_ =	'<td class="otherCell"><table width="100%">'
	+'<tr>'
	+'<td id="field_file_{#id}">'
	
	+'<table style="width:100%;"><tr><td class="batchUploadFrame" cfgName="{#fileCfg}" hasListFrame="1" {#inputType} realfileFrameId="{#id}" frameId="{#id}_b" frameSrc="/project/document/batUploadabsFlow.jsp?fieldName={#id}&inputType={#inputType}" frameType="4">'
		+'<div style="position: absolute;overflow:hidden;width:50px;height:18px;{#disabled}" class="formlink"><a  id="{#id}Btn" href="#" onclick="FileUpload.searchFile(this);" >添加附件</a>'
		+'<div id="upFileHid{#id}" style="position: relative; top: -14px; left: -5px;" {#disabled}></div>'
		+'</div></br>'
	+'</td></tr><tr><td>'
		+'<iframe id="{#id}" {#cstProperty} name="{#id}" onload="FileUpload.loadFileFrame(this, {#fileCfg},\'upFileHid{#id}\');" width="100%" height="0px;" frameborder="0" scrolling="no" src="/project/system/documnet/attachments/objectAttachmentsAction.do?type=4&wfid={#entityID}&wfstepid={#entityInstanceID}&fieldName={#id}&workFlowStepids={#workFlowStepids}"></iframe>'
	+'</td></tr></table>'
	
	+'</td>'
	+'</tr>'
	+'</table></td>';

//var _file = '<div class="input" id="{#id}"><a href="JavaScript:void(0)" target="_blank" onclick="showPdf(true,{#id})">0001_pdf</a></div>';

//var _file = '<div class="input" id="{#id}"><a href="JavaScript:void(0)" class="" target="" onclick="showPdf(true,\'{#id}\')">{#value}</a><a href="JavaScript:void(0)" class="" target="" onclick="showPdf(true,\'{#id}\')">{#value}</a></div>';
//var _file = '<div class="input1" id="{#id}">{#value}</div>';
var _file = '{#value}';
var _fileRead =	'<td class="otherCell"><table width="100%">'
	+'<tr>'
	+'<td id="field_file_{#id}">'
	
	+'<table style="width:100%;"><tr><td>&nbsp;</td></tr><tr><td>'
		+'<iframe id="{#id}" {#cstProperty} name="{#id}" onload="FileUpload.loadFileFrame(this, {#fileCfg},\'upFileHid{#id}\');" width="100%" height="0px;" frameborder="0" scrolling="no" src="/project/system/documnet/attachments/objectAttachmentsAction.do?type=4&wfid={#entityID}&wfstepid={#entityInstanceID}&fieldName={#id}&workFlowStepids={#workFlowStepids}&inputType={#inputType}"></iframe>'
	+'</td></tr></table>'
	
	+'</td>'
	+'</tr>'
	+'</table></td>';
var _file2 =	'<td class="otherCell"><table width="100%">'
	+'<tr>'
	+'<td id="field_file_{#id}">'
	
	+'<table style="width:100%;"><tr><td>&nbsp;</td></tr><tr><td>'
		+'<iframe id="{#id}" {#cstProperty} name="{#id}" onload="FileUpload.loadFileFrame(this, {#fileCfg},\'upFileHid{#id}\');" width="100%" height="0px;" frameborder="0" scrolling="no" src="/project/system/documnet/attachments/objectAttachmentsAction.do?type=4&wfid={#entityID}&wfstepid={#entityInstanceID}&fieldName={#id}&workFlowStepids={#workFlowStepids}&inputType={#inputType}"></iframe>'
	+'</td></tr></table>'
	
	+'</td>'
	+'</tr>'
	+'</table></td>';
var _file3 =	'<td class="otherCell"><table width="100%">'
	+'<tr>'
	+'<td id="field_file_{#id}">'
	
	+'<table style="width:100%;"><tr><td class="batchUploadFrame" cfgName="{#fileCfg}" hasListFrame="1" {#inputType} realfileFrameId="{#id}" frameId="{#id}_b" frameSrc="/project/document/batUploadabsFlow.jsp?fieldName={#id}" frameType="1"><a  id="{#id}Btn" href="#" onclick="FileUpload.searchFile(this);" >添加附件</a>'
		+'<div style="position: absolute;overflow:hidden;width:50px;height:18px;{#disabled}" class="formlink">'
		+'<div id="upFileHid{#id}" style="position: relative; top: -14px; left: -5px;" {#disabled}></div>'
		+'</div></br>'
	+'</td></tr><tr><td>'
		+'<iframe id="{#id}" isObject="true" {#cstProperty} name="{#id}" onload="FileUpload.loadFileFrame(this, {#fileCfg},\'upFileHid{#id}\');" width="100%" height="0px;" frameborder="0" scrolling="no" src="/project/system/documnet/attachments/objectAttachmentsAction.do?type=1&entityID={#entityID}&entityInstanceID={#entityInstanceID}&fieldName={#id}&inputType={#inputType}"></iframe>'
	+'</td></tr></table>'
	
	+'</td>'
	+'</tr>'
	+'</table></td>';
var _file4 =	'<td class="otherCell"><table width="100%">'
	+'<tr>'
	+'<td id="field_file_{#id}">'
	
	+'<table style="width:100%;"><tr><td>&nbsp;</td></tr><tr><td>'
		+'<iframe id="{#id}" isObject="true" {#cstProperty} name="{#id}" onload="FileUpload.loadFileFrame(this, {#fileCfg},\'upFileHid{#id}\');" width="100%" height="0px;" frameborder="0" scrolling="no" src="/project/system/documnet/attachments/objectAttachmentsAction.do?type=1&entityID={#entityID}&entityInstanceID={#entityInstanceID}&fieldName={#id}&inputType={#inputType}"></iframe>'
	+'</td></tr></table>'
	
	+'</td>'
	+'</tr>'
	+'</table></td>';
var _strHTML = "";
var _strGroup = "";
var tableID = 0;
var Form = {
	formFieldList: [],
	setFormField: function(cfg){
		Form.formFieldList.push(cfg);
	},
	getFormField: function(cfg){
		return Form.formFieldList;
	},
	addTable: function(table){// debugger;
		_strHTML = "";
		_strHTML += _strGroup+table.getHtml().replace('{#tableID}','table_id_' + tableID);
		_strGroup ="";
		//alert(_strHTML);
		tableID++;
	},
	addGroup: function(group){
		_strHTML += group.getHtml().replace('{#tableID}','table_id_' + tableID).replaceAll('{#groupID}','group_id_' + tableID);
		//alert(_strHTML+'---');
	},
	make: function(el){
		//String.prototype.replaceAll  = function(s1,s2){   
		//	return this.replace(new RegExp(s1,"gm"),s2);   
		//}
		//alert(typeof _strHTML == "string");
		//xx.innerHTML = _strHTML.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		
		document.getElementById(el).innerHTML = _strHTML;
	},
	Table: function(tablecfg){
		this.tableRow = [];
		this.currentCol = 'left';
		this.defaultWrap = tablecfg.defaultWrap;
		this.addRow = function(cfg){
			//获取添加元素的hmtl
			var strHtml = cfg.formItme.getHtml();
			
			var lable;
			//添加备注的lable
			if(cfg.formItme.getName() == "RemarkTextarae"){
				lable = _remark_lable.replace('{#lable}',cfg.lable);
			}else if(cfg.formItme.getName() == "FrameInput"){
				lable = '';
			}else{
				//元素的显示的名称 lable中的text
				lable = _lable.replace('{#lable}',cfg.lable);
			}
			// 1 用户；2 时间；3 对象 ；4 部门
			var aa = cfg.lable;
			var bb = "";debugger;
			if(aa.length>6){
					bb = "1";
			}
			if(cfg.cho==1){
				// lable = lable.replace('{#img}','<img src="../img/release@3x.png"/>');
				lable = lable.replace('{#class}','labelUser'+bb);
				
			}else if(cfg.cho==2){
				lable = lable.replace('{#class}','labelDate'+bb);
				
			}else if(cfg.cho==3||cfg.cho==4){
				lable = lable.replace('{#class}','labelObject'+bb);
				
			}
			else{
				lable = lable.replace('{#class}','label'+bb);
				
			}
			
			lable = lable.replace('{#img}','');
			//0：只读 1：可选输入 2：必须输入';
			//添加必输项标识
			if(cfg.mustInput == 2){
				lable = lable.replace('{#mustLable}',_mustLable);
			}else{
				lable = lable.replace('{#mustLable}',"");
			}
			//组合元素的名称 和 元素的hmtl
			strHtml = lable + strHtml;
			
			//增加到table格式中
			var fieldTable = _fieldTable.replace("{#content}", strHtml);
			//如果是单列布局
			
			if(cfg.col == 2){
				//添加到表格行中
				this.tableRow.push(_single_td.replace('{#content}', fieldTable));
				this.currentCol = 'left';
			}else{//如果是双列布局
				//添加到表格行中
				this.tableRow.push(_single_td.replace('{#content}', fieldTable));
				this.currentCol = 'left';
			}
		};
		this.getHtml = function(){
			var tr = "";
			for(var i=0;i<this.tableRow.length;i++){
				tr += _tr.replace('{#td}',this.tableRow[i].replace('{#content2}',''));
			}
			
			var html = _table.replace('{#tr}', tr);
			//defaultwrap;//默认展开 1:展开 0:收缩
			if(this.defaultWrap == '1'){
				html = html.replace('{#display}','');
			}else{
				html = html.replace('{#display}','display:none');
			}
			return html;
		};
	},
	getProperty: function(cfg){
		var property = _cstProperty.replace('{#propertyType}',cfg.propertyType).replace('{#systype}',cfg.systype);
		property = property.replace('{#propertyText}', cfg.propertyText);
		property = property.replace('{#mustInput}', cfg.mustInput);
		Form.setFormField(cfg);
		if(cfg.title){
			property = property + ' title="' + cfg.title + '" ';
		}
		if(cfg.onvc){
			property = property + ' onpropertychange="'+cfg.onvc+'" ';
		}
		return property;
	},
	Input: function(cfg){
		this.getName = function(){
			return "Input";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var className = "inputText";
			var readonly = "";
			var number = "false";
			//0：只读 1：可选输入 2：必须输入';
			var color = "#ffffff";
			var stylename = "";
			if(cfg.mustInput == 2){
				className = "inputTextCheck";
				color = "#f8ecd4";
			}else if(cfg.mustInput == 0){
				readonly = 'readonly';
				className = "readclass";
				color = "#f7f7f7";
				stylename ="background-color: rgb(251, 251, 251);"
			}
			//是否数字类型
			if(cfg.number == true){
				number = 'true';
			}
			
			
			
			var input = _input.replace('{#id}', cfg.id);
			input = input.replace('{#name}', cfg.id);
			input = input.replace('{#value}', cfg.value);
			input = input.replace('{#cstProperty}', property);
			input = input.replace('{#class}',className);
			input = input.replace('{#style}',stylename);
			input = input.replace('{#color}',color);
			input = input.replace('{#readonly}',readonly);
			input = input.replace('{#number}',number);
			input = input.replace('{#hidID}',cfg.hidID?cfg.hidID:"");
			input = input.replace('{#click}', '');
			return input;
		}
	},
	ObjectInput: function(cfg){
		// alert(JSON.stringify(cfg) );
		this.getName = function(){
			return "Input";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var className = "inputText";
			var readonly = "";
			var number = "false";
			//0：只读 1：可选输入 2：必须输入';
			var color = "#ffffff";
			var stylename= ""
			if(cfg.mustInput == 2){
				className = "inputTextCheck";
				color = "#f8ecd4";
			}else if(cfg.mustInput == 0){
				className = "readclass";
				color = "#f7f7f7";
				stylename="background-color: rgb(251, 251, 251);";
			}
			//是否数字类型
			if(cfg.number == true){
				number = 'true';
			}
			// alert(cfg.cho);
			// 1 用户；2 时间；3 对象 ；4 部门
			if(cfg.cho==1){
				className = "inputUser";
			}else if(cfg.cho==2){
				className = "inputDate";
				
			}else if(cfg.cho==3||cfg.cho==4){
				className = "inputObject";
			}else{
				// className = "inputUser";
				
			}
			debugger;
			var input = _input.replace('{#id}', cfg.id);
			input = input.replace('{#name}', cfg.id);
			input = input.replace('{#value}', cfg.value);
			input = input.replace('{#cstProperty}', property);
			input = input.replace('{#class}',className);
			input = input.replace('{#style}',stylename);
			input = input.replace('{#color}',color);
			input = input.replace('{#readonly}','readonly');
			input = input.replace('{#hidID}',cfg.hidID?cfg.hidID:"");
			input = input.replace('{#number}',number);

			if(cfg.mustInput == 0){
				input = input.replace('{#click}', '');
			}else{
				input =input.replace('{#click}', cfg.clickFn);
			}
			input = input.replace('{#icon}',cfg.icon);
			return input;
		}
	},
	File: function(cfg){
		this.getName = function(){
			return "File";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var file = _file.replace('{#cstProperty}', property);
			file = file.replaceAll('{#inputType}', cfg.inputType);
			file = file.replaceAll('{#id}', cfg.id);
			file = file.replaceAll('{#workFlowStepids}', cfg.workFlowStepids);
			file = file.replaceAll('{#entityID}', cfg.entityID);
			file = file.replaceAll('{#entityInstanceID}', cfg.entityInstanceID);
			file = file.replaceAll('{#fileCfg}', cfg.fileCfg);
			file = file.replaceAll('{#disabled}', cfg.inputType==0?'display:none;':'');
			file = file.replaceAll('{#inputType}', cfg.inputType==0?'inputType="'+cfg.inputType+'"':'');
			file = file.replaceAll('{#value}', cfg.value);
			return file;
		};
	},
	FileRead: function(cfg){
		this.getName = function(){
			return "File";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var file = _fileRead.replace('{#cstProperty}', property);
			file = file.replaceAll('{#inputType}', cfg.inputType);
			file = file.replaceAll('{#id}', cfg.id);
			file = file.replaceAll('{#workFlowStepids}', cfg.workFlowStepids);
			file = file.replaceAll('{#entityID}', cfg.entityID);
			file = file.replaceAll('{#entityInstanceID}', cfg.entityInstanceID);
			file = file.replaceAll('{#fileCfg}', cfg.fileCfg);
			file = file.replaceAll('{#disabled}', cfg.inputType==0?'display:none;':'');
			file = file.replaceAll('{#inputType}', cfg.inputType==0?'inputType="'+cfg.inputType+'"':'');
			return file;
		};
	},File2: function(cfg){
		this.getName = function(){
			return "File";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var file = _file2.replace('{#cstProperty}', property);
			file = file.replaceAll('{#inputType}', cfg.inputType);
			file = file.replaceAll('{#id}', cfg.id);
			file = file.replaceAll('{#workFlowStepids}', cfg.workFlowStepids);
			file = file.replaceAll('{#entityID}', cfg.entityID);
			file = file.replaceAll('{#entityInstanceID}', cfg.entityInstanceID);
			file = file.replaceAll('{#fileCfg}', cfg.fileCfg);
			file = file.replaceAll('{#disabled}', cfg.inputType==0?'display:none;':'');
			return file;
		};
	},
	File3: function(cfg){
		this.getName = function(){
			return "File";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var file = _file3.replace('{#cstProperty}', property);
			file = file.replaceAll('{#inputType}', cfg.inputType);
			file = file.replaceAll('{#id}', cfg.id);
			file = file.replaceAll('{#workFlowStepids}', cfg.workFlowStepids);
			file = file.replaceAll('{#entityID}', cfg.entityID);
			file = file.replaceAll('{#entityInstanceID}', cfg.entityInstanceID);
			file = file.replaceAll('{#fileCfg}', cfg.fileCfg);
			file = file.replaceAll('{#disabled}', cfg.inputType==0?'display:none;':'');
			return file;
		};
	},
	FileObjectRead: function(cfg){
		this.getName = function(){
			return "File";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var file = _file4.replace('{#cstProperty}', property);
			file = file.replaceAll('{#inputType}', cfg.inputType);
			file = file.replaceAll('{#id}', cfg.id);
			file = file.replaceAll('{#workFlowStepids}', cfg.workFlowStepids);
			file = file.replaceAll('{#entityID}', cfg.entityID);
			file = file.replaceAll('{#entityInstanceID}', cfg.entityInstanceID);
			file = file.replaceAll('{#fileCfg}', cfg.fileCfg);
			file = file.replaceAll('{#disabled}', cfg.inputType==0?'display:none;':'');
			return file;
		};
	},
	MoneyInput: function(cfg){
		this.getName = function(){
			return "Input";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var className = "inputText";
			var readonly = "";
			var number = "false";
			var stylename = "";
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 2){
				className = "inputTextCheck";
			}else if(cfg.mustInput == 0){
				readonly = 'readonly';
				className = "readclass";
				stylename ="background-color: rgb(251, 251, 251);"
			}
			//是否数字类型
			if(cfg.number == true){
				number = 'true';
			}
			var _moneyInput = '<div class="input"><input id="{#id}" name="{#name}" hidID="{#hidID}" number="{#number}" type="text" onkeypress="{#onkeypress}" onfocus="{#onfocus}" onblur="{#onblur}" class="{#class}" style="{#style}" value="{#value}" {#cstProperty} {#readonly}/></div>';
			var input = _moneyInput.replace('{#id}', cfg.id);
			input = input.replace('{#name}', cfg.id);
			input = input.replace('{#value}', MoneyObj.covert2MoneyStr(cfg.value));
			input = input.replace('{#cstProperty}', property);
			input = input.replace('{#class}',className);
			input = input.replace('{#style}',stylename);
			input = input.replace('{#onkeypress}','return MoneyObj.textIsNumbers(event,this)');
			input = input.replace('{#onfocus}','MoneyObj.removeMoneyFormat(this);');
			input = input.replace('{#onblur}','MoneyObj.convert2Money(this)');
			input = input.replace('{#readonly}',readonly);
			input = input.replace('{#number}',number);
			
			return input;
		}
	},
	SearchInput: function(cfg){
		this.getName = function(){
			return "SearchInput";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var className = "inputText";
			var readonly = "";
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 2){
				className = "inputTextCheck";
			}else if(cfg.mustInput == 0){
				className = "readclass";
			}
			var input = _input.replace('{#id}', cfg.id);
			input = input.replace('{#name}', cfg.id);
			input = input.replace('{#value}', cfg.value);
			input = input.replace('{#cstProperty}', property);
			input = input.replace('{#class}',className);
			input = input.replace('{#readonly}','readonly');
			input = input.replace('{#hidID}',cfg.hidID?cfg.hidID:"");
			
			var imgBtn = "";
			if(cfg.mustInput == 0){
				imgBtn = _searchInput.replace('{#click}', '');
			}else{
				imgBtn =_searchInput.replace('{#click}', cfg.clickFn);
			}
			
			//查找按钮的图标 默认为[放大镜]
			if(cfg.icon == NULL){
				imgBtn = imgBtn.replace('{#icon}','/project/images/icon/icon59.gif');
			}else{
				imgBtn = imgBtn.replace('{#icon}',cfg.icon);
			}
			
			return input + imgBtn;
		}
	},
	Select: function(cfg){
		this.getName = function(){
			return "Select";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var opHtml = "";
			var html = "";
			var className = "";
			var stylename= "";
			for(var i=0;i<cfg.option.length;i++){
				var item = cfg.option[i];
				opHtml += _selectOption.replace('{#value}', item.value).replace('{#text}', item.text);
				if(item.selected == true){
					opHtml = opHtml.replace('{#selected}', 'selected');
				}else{
					opHtml = opHtml.replace('{#selected}', '');
				}
			}
			
			html = _select.replace('{#id}', cfg.id).replace('{#option}', opHtml).replace('{#cstProperty}', property);
			
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 2){
				//className = "inputSelectCheck";
			}else if(cfg.mustInput == 0){
				stylename = "background-color: rgb(230, 230, 230);";
				html = html.replace('{#disabled}','disabled');
				//className = "inputSelectRead";
			}
			html = html.replace('{#style}',stylename);
			html = html.replace('{#class}',className);
			
			return html;
		}
	},
	SelectList: function(cfg){
		this.getName = function(){
			return "SelectList";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var opHtml = "";
			for(var i=0;i<cfg.option.length;i++){
				var item = cfg.option[i];
				opHtml += _selectOption.replace('{#value}', item.value).replace('{#text}', item.text);
				if(item.selected == true){
					opHtml = opHtml.replace('{#selected}', 'selected');
				}else{
					opHtml = opHtml.replace('{#selected}', '');
				}
			}
			var multiple = "";
			if(cfg.multiple == true){
				multiple = "multiple";
			}
			
			var html = _selectList.replace('{#id}', cfg.id).replace('{#option}', opHtml).replace('{#cstProperty}', property).replace('{#multiple}', multiple).replace('{#size}', cfg.size);
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 0){
				html = html.replace('{#disabled}','disabled');
			}else if(cfg.mustInput == 2){
				html = html.replace('{#disabled}','');
			}
			return html;
		}
	},
	DateInput: function(cfg){
		this.getName = function(){
			return "DateInput";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var className = "inputText";
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 2){
				className = "inputTextCheck";
			}else if(cfg.mustInput == 0){
				className = "readclass";
			}
			var input = _input.replace('{#id}', cfg.id);
			var stylename = "";
			input = input.replace('{#name}', cfg.id);
			input = input.replace('{#value}', cfg.value);
			input = input.replace('{#cstProperty}', property);
			if(cfg.cho==2){
				className = "inputDate";
				
			}
			input = input.replace('{#class}',className);
			input = input.replace('{#readonly}','readonly');
			
			//var imgBtn = "";

			if(cfg.mustInput == 0){
				input = input.replace('{#click}', '');
				stylename = "background-color: rgb(251, 251, 251);";
				//imgBtn = _dateInput.replace('{#click}', '');
			}else{
				//input = input.replace('{#click}', 'showCalendar('+cfg.id+','+cfg.id+','+cfg.id+',\'\')');
				//imgBtn = _dateInput.replace('{#click}', 'showCalendar('+cfg.id+','+cfg.id+','+cfg.id+',\'\')');
				input = input.replace('{#click}', 'showDate('+cfg.id+','+cfg.id+','+cfg.id+',\'\')');
			}
			input = input.replace('{#style}', stylename);
			input = input.replace('{#icon}', "/project/images/icon/icon50.gif");
			return input;
		}
	},
	Radiobox: function(cfg){
		this.getName = function(){
			return "Radiobox";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var opHtml = "";
			var stylename = "";
			for(var i=0;i<cfg.valueList.length;i++){
				var item = cfg.valueList[i];
				
				opHtml += _radiobox.replace('{#value}', item.value).replace('{#text}', item.text).replace('{#name}', cfg.id);
				opHtml = opHtml.replace('{#cstProperty}', property);
				if(item.checked == true){
					opHtml = opHtml.replace('{#checked}', 'checked');
				}else{
					opHtml = opHtml.replace('{#checked}', '');
				}
				//0：只读 1：可选输入 2：必须输入';
				if(cfg.mustInput == 0){
					opHtml = opHtml.replace('{#disabled}','disabled');
					opHtml = opHtml.replace('{#style}','background-color: rgb(251, 251, 251);');
				}else if(cfg.mustInput == 2){
					opHtml = opHtml.replace('{#disabled}','');
				}else{
					opHtml = opHtml.replace('{#disabled}','');
				}
			}
			 // alert(opHtml);
			return _radio.replace('{#radiobox}', opHtml);
		}
	},
	Checkbox: function(cfg){
		this.getName = function(){
			return "Checkbox";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var opHtml = "";
			var stylename= '';
			for(var i=0;i<cfg.valueList.length;i++){
				var item = cfg.valueList[i];
				opHtml += _checkbox.replace('{#value}', item.value).replace('{#text}', item.text).replace('{#name}', cfg.id);
				opHtml = opHtml.replace('{#cstProperty}', property);
				if(item.checked == true){
					opHtml = opHtml.replace('{#checked}', 'checked');
				}else{
					opHtml = opHtml.replace('{#checked}', '');
				}
				//0：只读 1：可选输入 2：必须输入';
				if(cfg.mustInput == 0){
					stylename= 'background-color: rgb(251, 251, 251);';
					opHtml = opHtml.replace('{#disabled}','disabled');
				}else if(cfg.mustInput == 2){
					opHtml = opHtml.replace('{#disabled}','');
				}
				opHtml = opHtml.replace('{#style}',stylename);
			}
			return _radio.replace('{#radiobox}', opHtml);
		}
	},
	Textarae: function(cfg){
		this.getName = function(){
			return "Textarae";
		};
		this.getHtml = function(){
			var className = "inputTextarea";
			var property = Form.getProperty(cfg);
			var input = _textarae.replace('{#id}', cfg.id).replace('{#value}', cfg.value).replace('{#cstProperty}', property);
			
			input = input.replace('{#rows}', cfg.rows);
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 0){
				input = input.replace('{#readonly}','readonly');
				className = "inputTextareaRead";
			}else if(cfg.mustInput == 2){
				input = input.replace('{#readonly}','');
				className = "inputTextareaCheck";
			}
			
			input = input.replace('{#class}',className);
			return input;
		}
	},
	RichText: function(cfg){
		this.getName = function(){
			return "RichText";
		};
		this.getHtml = function(){
			Form.getProperty(cfg);
			var rows = cfg.rows * 50;
			var input = _richText.replaceAll('{#id}', cfg.id).replace('{#value}', cfg.value).replace('{#height}', rows);
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput == 0){
				input = input.replace('{#mustInput}', "true");
			}
			else {
				input = input.replace('{#mustInput}', "false");
			}
			input = input.replace('{#click}', "openRich('"+cfg.id+"')");
			
			//alert(cfg.mustInput);
			/*
			//0：只读 1：可选输入 2：必须输入';
			if(cfg.mustInput != 0){
				input = input.replace('{#button}','<div style="height:20px;margin-top:5px;" class="formlink"><a style="cursor: pointer;" href="javascript:editRichText(\''+cfg.id+'\')" >编辑富文本信息</a></div>');
			}else{
				input = input.replace('{#button}','');
			}
			*/
			//input = input.replace('{#button}','');
			return input;
		}
	},
	FrameInput: function(cfg){
		this.getName = function(){
			return "FrameInput";
		};
		
		if(window.attachEvent){
			window.attachEvent('onlaod',function(){
			});
		}else{
			window.addEventListener('load',function(){
				var th=document.body.clientHeight,ah=0;
				jQuery('.form_body_frame_table').each(function(i){						
					ah+=this.scrollHeight+5;
				});
				ah-=document.getElementById('frame_'+cfg.id).clientHeight;
				//if(ah<th){
				//	if((th-ah-22-7)<300){
				//		document.getElementById('frame_'+cfg.id).style.height='100px';
				//	}else{
						document.getElementById('frame_'+cfg.id).style.height=(cfg.rows * 50)+'px';
				//	}
				//}else{
				//	document.getElementById('frame_'+cfg.id).style.height='100px';
				//}
			},false);	
		}
		this.getHtml = function(){
			Form.getProperty(cfg);
			var rows = cfg.rows * 50;
			var input = _frame.replaceAll('{#id}', cfg.id).replace('{#height}', rows).replace('{#src}',cfg.frameSrc);
			return input;
		}
	},
	RemarkTextarae: function(cfg){
		this.getName = function(){
			return "RemarkTextarae";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var input = _remark_textarae.replace('{#id}', cfg.id).replace('{#value}', cfg.value).replace('{#cstProperty}', property);
			if(cfg.addRemark == true){
				input = input.replace('{#display}','');
			}else{
				input = input.replace('{#display}','display:none');
			}
			input = input.replace('{#rows}', cfg.rows);

			input = input.replace('{#readonly}','readonly');

			return  input;
		}
	},
	Group: function(cfg){
		this.getHtml = function(){
			var html = _group.replace('{#title}', cfg.title);
			
			_strGroup = html;
			return html;
		}	
	},
	Link: function(cfg){
		this.getName = function(){
			return "Link";
		};
		this.getHtml = function(){
			var property = Form.getProperty(cfg);
			var html = _link_field.replace('{#click}', cfg.clickFn);
			var html = html.replace('{#text}', cfg.value);
			return html;
		}
	},
	displayGroup: function(obj,divName,grpName){
		var objArr = obj.getElementsByTagName('div');
		for(var i=0;i<objArr.length;i++){
			if(objArr[i].className == 'formgroup_icon_hidden'){
				objArr[i].className = 'formgroup_icon_visible';
				break;
			}
			if(objArr[i].className == 'formgroup_icon_visible'){
				objArr[i].className = 'formgroup_icon_hidden';
				break;
			}
		}
		
		var objGroup = document.getElementById(divName);
		if(objGroup.style.display == undefined || objGroup.style.display == ''){
			objGroup.style.display = 'none';
		}else{
			objGroup.style.display = '';
		}
		
		var objGrp = document.getElementById(grpName);
		if (objGrp.className == 'formgroup2') {
			objGrp.className = 'formgroup';
		} else {
			objGrp.className = 'formgroup2';
		}
	},
	getFieldData: function(){
		$(document.body).trigger("mousedown");
		var fieldList = Form.formFieldList;
		var list = [];
		for(var i=0;i<fieldList.length;i++){
			var field = fieldList[i];
			this.FieldHelper.process(field);
			list.push(field);
		}
		return list;
	},	

//	字段的类型 
//	0：字符串; 1：多行文本; 2：金额; 4：数字; 8：时间; 
//	11：单选列表; 12：复选列表; 15 单选框;	16: 复选框;
//	81: 复选用户; 82: 复选项目; 83：复选部门; 91: 用户; 92：项目; 93：部门; 
//	94：实体; 97：合同; 98：项目群； 999: 通用查找
//	Form.FieldHelper.registHandler({
//		handleThis: function(field){
//			return field.propertyType==12;
//		},
//		process: function(field){
//			var obj = document.getElementById(field.id);
//			var arrValue = [];
//			for(var j=0;j<obj.options.length;j++){
//				if(obj.options[j].selected){
//					arrValue.push(obj.options[j].value);
//				}
//			}
//			field.value = arrValue.toString();
//			return field;
//		}
//	});
	FieldHelper:{
		handlers: [],
		/**扩展字段处理引擎*/
		registHandler: function(handle){
			this.handlers.push(handle);
		},
		process: function(field){
			/**用户扩展处理引擎*/
			var activeHandler = undefined;
			for(var i=0, len=this.handlers.length;i<len;i++){
				var handler = this.handlers[i];
				if(handler.handleThis(field)){
					activeHandler = handler;
				}
			}
			if(activeHandler){
				activeHandler.process(field);
				return field;
			}
			//默认处理引擎
	    	var typeStr = ","+field.propertyType+",";
	    	if(',0,1,2,4,8,11,81,82,83,85,91,92,93,94,95,97,98,999,995,84,'.indexOf(typeStr)>=0){
	    		var obj = document.getElementById(field.id);
				if(',91,92,93,94,97,98,81,82,83,999,84,'.indexOf(typeStr)>=0){
					field.value = obj.getAttribute("hidID");
				}else{
					field.value = obj.value || "";
				}
		    }else if(',12,'.indexOf(typeStr)>=0){//12：复选列表
		    	var obj = document.getElementById(field.id);
				var arrValue = [];
				for(var j=0;j<obj.options.length;j++){
					if(obj.options[j].selected){
						arrValue.push(obj.options[j].value);
					}
				}
				field.value = arrValue.toString();
		    }else if(',15,16,'.indexOf(typeStr)>=0){//15 单选框 16 复选框
		    	var arrValue = [];
				var obj = document.getElementsByName(field.id);
				for(var j=0;j<obj.length;j++){
					if(obj[j].checked){
						arrValue.push(obj[j].value);
					}
				}
				field.value = arrValue.toString();
		    }else if(',30,'.indexOf(typeStr)>=0){//富文本
//		    	field.value = encodeURIComponent(document.getElementById("preview4Ueditor_"+field.id).contentWindow.getValue());
		    }
			return field;
		}
	}
};
function toSearchUserMult(name){
	var node = document.getElementById(name);
    var objData = new Object();
	objData.userID = node.getAttribute("hidID");
	objData.userName = node.value;
	objData.multiple = true;
	objData.name = name;
	var obj = Search.user(objData);
	if(obj){
		node.setAttribute("hidID", obj.userID);
		node.value = obj.userName;
		node.title = node.value;
		if(objData.userID!=obj.userID){
			if(node.change){
				node.change();
			}
		}
	}
}
function toSearchProjectMult(name){
	var node = document.getElementById(name);
	var objData = new Object();
	objData.projectID = node.getAttribute("hidID");
	objData.projectName = node.value;
	objData.multiple = true;
	objData.name = name;
	objData.type = 1;
	var obj = Search.project(objData);
	if(obj){
		node.setAttribute("hidID", obj.projectID);
		node.value = obj.projectName;
		node.title = node.value;
		if(objData.projectID!=obj.projectID){
			if(node.change){
				node.change();
			}
		}
	}
}
function toSearchDeptMult(name){
	var node = document.getElementById(name);
	var objData = new Object();
	objData.departmentID = node.getAttribute("hidID");
	objData.departmentName = node.value;
	objData.multiple = true;
	objData.name = name;
	var obj = Search.department(objData);
	if(obj){
		node.setAttribute("hidID", obj.departmentID);
		node.value = obj.departmentName;
		node.title = node.value;
		if(objData.departmentID!=obj.departmentID){
			if(node.change){
				node.change();
			}
		}
	}
}




function resizeBatchFrame(size,frameId){
	var bf=document.getElementById(frameId);
	if(bf){
		bf.style.height=size+'px';
	}
	var rf=frameId.substring(0,frameId.length-2);
}
function flashChecker(nv){
	try{
	nv=parseFloat(nv);
    var hasFlash=0;　　　　//是否安装了flash
    var flashVersion=0;　　//flash版本
    if(document.all){
        var swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash'); 
        if(swf){
	        hasFlash=true;
	        VSwf=swf.GetVariable("$version");
	        flashVersion=parseFloat(VSwf.split(" ")[1].replace(/,/g,'.'));
	       
        }
    }else{
        if(navigator.plugins&&navigator.plugins.length>0){
	        var swf=navigator.plugins["Shockwave Flash"];
	        if (swf){
	        	hasFlash=true;
	            var words = swf.description.split(" ");
	            for (var i = 0; i < words.length; ++i){
	                 if(isNaN(parseFloat(words[i]))) 
	                	 continue;
	                 flashVersion = parseFloat(words[i]);
	        	}
	        }
        }
	}
    if(hasFlash&&flashVersion>=nv){
    	return true;
    }else{
    	return false;
    }
	}catch(e){
		return false;
	}
}

/*
(function(){
	
	var func=function(){
		if(flashChecker(9.0)){
			jQuery('.batchUploadFrame').each(function(){
				var cur=this;
				var cfgName=cur.getAttribute("cfgName");
				if(cfgName){
					if(!window[cfgName].isMultiFile){
						return;
					}
				}
				
				var frameId=cur.getAttribute('frameId')||'';
				var frameType=cur.getAttribute('frameType');
				var hasListFrame=cur.getAttribute('hasListFrame')||'0';
				var realfileFrameId=cur.getAttribute('realfileFrameId')||'fileIfrm1';
				var frameSrc=cur.getAttribute('frameSrc')||'/project/document/batUploadabs.jsp?time=10000';
				cur.innerHTML=' <iframe name="'+frameId+'" id="'+frameId+'" allowtransparency="true" src="'+frameSrc+'&type='+frameType+'&msgID='+frameId+'&realfileFrameId='+realfileFrameId+'&hasListFrame='+hasListFrame+'" frameborder="0" scrolling="no"  style="width:100%;height:20px;" ></iframe>';
				cur.style.height='20px';
				var inputType = cur.getAttribute('inputType');
				if(inputType==0){
					cur.style.display='none';
				}
			});
		};
		

		
	};
	if(window.attachEvent){
		window.attachEvent('onload',func);
	}else{
		window.addEventListener('load',func,false);
	}
})();
*/ 
//编辑富文本信息
function editRichText(fieldName){
	//window.richText = document.getElementById('preview4Ueditor_'+fieldName).contentWindow.getValue();
	//Common.showModalWin("/project/ueditor/ueditorToolbar.jsp",window,800,600,function(res){
	//	if(res!=undefined){//返回值
	//		document.getElementById('preview4Ueditor_'+fieldName).contentWindow.setValue(res);
	//	}
	//});
	window.richText = document.getElementById('preview4Ueditor_'+fieldName).contentWindow.getValue();
	var map = {};
	map['fieldName'] = fieldName;
	parent.parent.parent.dialog.openQueryEdit('富文本信息', "/project/ueditor/ueditorToolbar.jsp", map);
}
function getRichTextDivHtml(divName){
	return $('#'+divName).html();
}
// 移动端选择用户、部门、实体


//选择流程用户
function searchUser(stepcode,stepid,initusertype,usergroup,inituserid){
	var map = {};
	map['sueridv'] = 'step_user_'+stepid;
	map['susernamev'] = 'step_user_name_'+stepid;
	
	/* 参数不写格式，只写语义 */
	var dialogParam = { }; 
	/*
	dialogParam["userid"] = " in 1,2 "; 
	dialogParam["employeecode"] = " like 8 "; 
	dialogParam["username"] = " = user "; 
	// singleUser.jsp  multiUser.jsp
	*/
	dialog.openFull($("#headerTitleInfo").html(), '../flow/multiUser.jsp?itype=bpmuser&iflag='+initusertype+'&usergroup='+usergroup+'&inituserid='+inituserid+'&sparam=' + json.toJSON(dialogParam), map);
}
// 表单用户、部门
function doSelectUser(fieldName,itype,sm) {
	var map = {};
   //  map['sueridv'] = fieldName.hidid;
	map['susernamev'] = fieldName;
	
	/* 参数不写格式，只写语义 */
	var dialogParam = { }; 
	/*
	dialogParam["userid"] = " in 1,2 "; 
	dialogParam["employeecode"] = " like 8 "; 
	dialogParam["username"] = " = user "; 
	// singleUser.jsp  multiUser.jsp
	*/
	// itype :user,depart
	if(null==itype||''==itype){
		itype ='user';
	}
	
	var url = '../flow/singleUser.jsp';
	if('mult'==sm){
		url = '../flow/multiUser.jsp';
	}
	url +='?itype='+itype+'&sparam=' + json.toJSON(dialogParam);
	//dialog.openFull($("#headerTitleInfo").html(), 'multiUser.jsp?itype='+itype+'&sparam=' + json.toJSON(dialogParam), map);
	dialog.openFull($("#headerTitleInfo").html(), url, map);
}
//项目、项目群、对象
function doSelectObject(fieldName,itype,sm) {
	var map = {};
   //  map['sueridv'] = fieldName.hidid;
	map['susernamev'] = fieldName;
	
	/* 参数不写格式，只写语义 */
	var dialogParam = { }; 
	/*
	dialogParam["userid"] = " in 1,2 "; 
	dialogParam["employeecode"] = " like 8 "; 
	dialogParam["username"] = " = user "; 
	// singleUser.jsp  multiUser.jsp
	*/
	// itype :project,projectCst
	if(null==itype||''==itype){
		itype ='project';
	}
	
	var url = '../flow/singleObject.jsp';
	if('mult'==sm){
		url = '../flow/multiObject.jsp';
	}
	url +='?itype='+itype+'&sparam=' + json.toJSON(dialogParam);
	dialog.openFull($("#headerTitleInfo").html(), url, map);
}


var tmpData;

function showDate(id){
	id.addEventListener("click",function() {
	tmpData = id;
	toCalendar();
});
}	

function toHtmlDateTime(v) {
	tmpData.value = formatDate(v);
}


function showPdf(name,filetype,id,type) {
		if(!(filetype.indexOf('doc')>-1||filetype.indexOf('xls')>-1||filetype.indexOf('ppt')>-1)){
			// alert('暂不支持');
			return;
		}
		
		if(type== "undefined"||type==undefined){
			type="1";
		}
		window.location.href ='../common/showPdf.jsp?titleName='+encodeURI(encodeURI(titlename))+"&type="+type+"&fileid="+id;
}

 