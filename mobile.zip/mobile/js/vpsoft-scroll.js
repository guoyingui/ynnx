var myScroll,pullDownEl, pullDownOffset,pullUpEl;

function loaded() {
	//动画部分
	pullDownEl = document.getElementById('pullDown');
	pullUpEl = document.getElementById('pullUp');
	myScroll = new iScroll('wrapper', {
		hScrollerbar: true,
		useTransition: true,
		hideScrollbar: true,
		onRefresh: function () {
			
			if (pullDownEl.className.match('loading')) {
				pullDownEl.style.display = "none";
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullLabel').innerHTML = '下拉刷新';
				pullUpEl.querySelector('.pullLabel').innerHTML = '';
			} 
			else if (pullUpEl.className.match('loading')) {
				pullUpEl.className = '';
				if (hasmore) {
					pullUpEl.querySelector('.pullLabel').innerHTML = '上拉加载更多';
				}
				else {
					pullUpEl.style.display = "block";
					pullUpEl.querySelector('.pullLabel').innerHTML = '无更多数据';
				}
			}
			
			loadScript("../js/vpsoft-slide.js", function () { });
		},
		onScrollMove: function () {		
			if (this.y > 5 && !pullDownEl.className.match('flip')) {
				pullDownEl.style.display = "block";
				pullDownEl.className = 'flip';
				pullDownEl.querySelector('.pullLabel').innerHTML = '释放刷新';
				this.minScrollY = 0;
			}
			else if (this.y < 5 && pullDownEl.className.match('flip')) {
				pullDownEl.style.display = "block";
				pullDownEl.className = '';
				pullDownEl.querySelector('.pullLabel').innerHTML = '释放刷新';
				this.minScrollY = -pullDownOffset;
			}
			else if (this.y < (this.maxScrollY - 5) && !pullUpEl.className.match('flip')) {
				pullUpEl.style.display = "block";
				pullUpEl.className = 'flip';
				this.maxScrollY = this.maxScrollY;
				if (hasmore) {
					pullUpEl.querySelector('.pullLabel').innerHTML = '释放刷新';
				}
			}
			else if (this.y > (this.maxScrollY + 5) && pullUpEl.className.match('flip')) {
				pullUpEl.style.display = "block";
				pullUpEl.className = '';
				this.maxScrollY = pullUpOffset;
				if (hasmore) {
					pullUpEl.querySelector('.pullLabel').innerHTML = '释放刷新';
				}
			}
		},
		onScrollEnd: function () {
			if (pullDownEl.className.match('flip')) {
				pullDownEl.className = 'loading';
				pullDownEl.querySelector('.pullLabel').innerHTML = '加载中';
				pullDownAction();
			} else if (pullUpEl.className.match('flip')) {
				pullUpEl.className = 'loading';
				if (hasmore) {
					pullUpEl.querySelector('.pullLabel').innerHTML = '加载中';
					pullUpAction();
				}
				else {
					pullUpEl.querySelector('.pullLabel').innerHTML = '无更多数据';
				}
			}
		}
	});
	
	loadAction();
}
document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);//阻止冒泡
loaded();

//初始状态，加载数据
function loadAction(){	
	myScroll.refresh();
}

//下拉刷新当前数据
function pullDownAction () {
	setTimeout(function () {
		ipageno = 1;
		doLoadData();
		myScroll.refresh();	
	}, 400);
}

//上拉加载更多数据
function pullUpAction () {
	setTimeout(function () {
		if (hasmore) {
			doLoadData();
		}
		myScroll.refresh();
	}, 400);
}