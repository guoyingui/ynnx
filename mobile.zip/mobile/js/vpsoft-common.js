
var sbrowse = '';
var ua = navigator.userAgent.toLowerCase();
if (/android/.test(ua)) {
	sbrowse = 'Android';
} 
else if (/iphone|ipad|ipod/.test(ua)) {
	sbrowse = 'IOS';
} 
else {
	sbrowse = 'web';
}

/* 返回原生的方法 */
function doNativeBack() {
	if (sbrowse == 'Android'){
		androidObj.onBack();
	} 
	else if (sbrowse == 'IOS'){
		window.location.href = "ios::close";
	} 
	else {
		history.go(-1);
	}
}

/* 返回原生的方法 */
function doNativeRelogin() {
	if (sbrowse == 'Android'){
		androidObj.onRelogon();
	} 
	else if (sbrowse == 'IOS'){
		window.location.href = "ios::relogon";
	} 
	else {
		window.location.href = "/login.jsp";
	}
}

/* H5之前的链接返回 */
function doH5Back() {
	history.go(-1);
}

function returnUsers(hidev, dspv) {
}

function loadScript(url, callback) {
	var script = document.createElement("script");
	script.type = "text/javascript";
	if(typeof(callback) != "undefined"){
		if (script.readyState) {
			script.onreadystatechange = function () {
				if (script.readyState == "loaded" || script.readyState == "complete") {
					script.onreadystatechange = null;
					callback();
				}
			};
		} 
		else {
			script.onload = function () {
				callback();
			};
		}
	}
	script.src = url;
	document.body.appendChild(script);
}

var json={
	isSimple:function(o){
		var is=false;
		var type=Object.prototype.toString.apply(o);
		if(type=='[object Array]'||type=='[object Function]'||type=='[object Object]'){
			is=false;
		}else{
			is=true;
		}
		return is ;
	},
	toDateStr:function(o){
		var m=o.getMonth()+1;
		var s=[o.getFullYear(),(m>9?'':'0')+m,(o.getDate()>9?'':'0')+o.getDate()];
		return s.join('-');
	
	},
	isInput:function(o){
		return Object.prototype.toString.apply(o)=='[object HTMLInputElement]';
	},
	isObj:function(o){
		var type=Object.prototype.toString.apply(o);
		return type=='[object Object]';
	},
	isArray:function(o){
		return Object.prototype.toString.apply(o)=='[object Array]';
	},
	isFunc:function(o){
		return Object.prototype.toString.apply(o)=='[object Function]';
	},
	isSimple:function(o){
		var type=Object.prototype.toString.apply(o);
		return (type=='[object String]'||type=='[object Number]');
	},
	isDate:function(o){
		return Object.prototype.toString.apply(o)=='[object Date]';
	},
	isNumber:function(o){
		var type=Object.prototype.toString.apply(o);
		return type=='[object Number]';
	},
	toJSON:function(o){		
		if(json.isObj(o)){
			var jstr='{',j=0;
			for(var i in o){
				var cur=o[i];
				if(cur!==undefined&&cur!==null&&!json.isFunc(cur)){
					var brace=json.isSimple(cur)?(json.isNumber(cur)?'':'"'):'';
					jstr+=(j!=0?',"':'"')+i+'":'+brace+json.toJSON(cur)+brace;
					j++;
				}
			}
			jstr+='}';
			
			return jstr;
		}
		else if(json.isArray(o)){
			var str=[];
			for(var k=0;k<o.length;k++){
				var cur=o[k],brace=json.isSimple(cur)?(json.isNumber(cur)?'':'"'):'';
				str.push(brace+json.toJSON(cur)+brace);
			}
			return '['+str.join(',')+']';
		}
		else if(json.isDate(o)){
			return json.toDateStr(o);
		}
		else{			
			return o;
		}
	}
};

var firstLoad = 0;
var ipageno = 1;
var hasmore = false;
var param = { };  
param["ipagesize"] = 20;
function paseNavData(data) { 	
	if (firstLoad == 0 ) {
		$("#headerTitle").html(data.titleName);
		if (data.headerTitleInfo != undefined) {
			$("#headerTitleInfo").html(data.headerTitleInfo);
		}
		if (data.searchText != undefined) {
			$("#searchvalue").attr("placeholder", data.searchText);
		}
		if (data.filterTabs != undefined) {
			var pageSize = 3;//显示3个过滤器
			var str_ = "";
			if(data.startNum>0&&data.tabTotals>4){
				str_+= "<span onclick='toNext(-1)' ><img src='../img/ar_left.png' style='height: 0.8rem;' /></span>";
			}
			$.each(data.filterTabs, function(i, item) {
				str_ += '<span id="tab'+i+'" value="'+item.svalue+'" class="'+item.sclass+'" onclick="doFilterClick(this)">'+item.stext+'</span>';
				str_ += "<input type='hidden' id='index_"+item.svalue+"' name='index_"+item.svalue+"' value='"+item.rownum+"' >";
			});
			if(data.tabTotals>data.startNum+pageSize){
				str_+= "<span onclick='toNext(1)' ><img src='../img/ar_right.png' style='height: 0.8rem;' /></span>";
			}
			
			str_+= "<input type='hidden' id='startNum' name='startNum' value='"+data.startNum+"' >";
			$("#filterDiv").html(str_);
		}
		firstLoad++;
	}
}

function loadData() {
	$.ajax({  
        type: "GET", 
        url: param.url,
		data: param, 
		async: true, 
        dataType: "json", 
        success: function(data) {
			try	{
				if (data.sucess) {
					paseNavData(data);
					var pageSize = 3;//显示3个过滤器
					if(data.startNum>=0&&data.tabTotals>=data.startNum+pageSize){ // 当刷新时清空
						$("#filterDiv").html("");
						firstLoad = 0;
					}else{
						firstLoad++;
					}
					paseNavData(data);

					if (ipageno == 1) { // 当刷新时清空
						$("#thelist").html("");
					}					
					paseListData(data);
					if (data.hasmore) {
						ipageno++;
						hasmore = true;
					}
					else {
						document.getElementById('pullUp').querySelector('.pullLabel').innerHTML = ''; 
						hasmore = false;
					}
				}
				else {
					if (data.code == '200') {
						doNativeRelogin();
					}
					else {
						new TipBox(data.message);
					}
				}
			}
			catch (e) {
				new TipBox('解析数据错误：' + e);
			}
        },
		complete: function(XMLHttpRequest, textStatus) {
			if (typeof(myScroll) != 'undefined') {				
				setTimeout(function() {
					myScroll.refresh();
				}, 1500);
			}
		},
		error: function(ht) {  
			new TipBox("系统错误，请重试");  
		}
    });
}

function doLoadData() {
	param["ipageno"] = ipageno; 
	param["searchvalue"] = encodeURI(encodeURI($("#searchvalue").val())); 
    loadData(); 
}

function toUrl(url) {
	window.location.href = url;
}

function doCheckTab(obj) {
	if (obj.parentElement.querySelector(".on") != null) {
		var srcclass = obj.parentElement.querySelector(".on").getAttribute("srcclass");
		if (srcclass == null) {
			obj.parentElement.querySelector(".on").className = "";
		}
		else {
			obj.parentElement.querySelector(".on").className = srcclass;
		}
	}
	obj.className = "on";
}

function doFilterClick(obj) {
	doCheckTab(obj);
	ipageno = 1;
	debugger;
	param["sfilter"] = obj.getAttribute("value"); 
	
	var indexStr = "index_"+$('span.on').attr("value");
	var startNum = parseInt($("#startNum").val());
	var pageSize = 3;//显示3个过滤器
	var nextFlag = parseInt($("#"+indexStr).val())-pageSize;
	var prevFlag = parseInt($("#"+indexStr).val())-startNum; 
	
	if(nextFlag == startNum) {
		toNext(1);
	}
	else if(prevFlag == 1) {
		toNext(-1);
	} 
	else {
		toNext(0);
	} 
}

function toNext(offset) {
	doLoadData();
	return false;
}

function toSearch() {
	ipageno = 1;
	doLoadData();
	return false;
}

function initFooter() {
	if ($("#footerDiv") != undefined) {
		// $("#footerDiv").css("top", (screen.availHeight - (2.5+2)*23) + "px");
		var w = 100 / $("#footerDiv").children().length - 1;
		$("#footerDiv div").each(
			function() {
				 $(this).css("width", w + "%");
			}
		);
	}
}

function doEnsure() {
	var hidev = "", dspv = "";
	$("div.sl-content[selected=true]").each(function() { 
		hidev += $(this).attr("hidevalue") + ",";
		dspv += $(this).attr("displayname") + ",";
	});
	if (hidev == '') {
		new TipBox('请选择');
		return;
	}
	else {
		doReturn(hidev.substr(0, hidev.length - 1), dspv.substr(0, dspv.length - 1));
	}
}

function doCancel() {
	doReturn('', '');
}

function toCalendar() {debugger;
	if (sbrowse == 'Android'){
		androidObj.onCalendar();
	} 
	else if (sbrowse == 'IOS'){
		// window.location.href = "ios::calendar::"+id;
		// 调用ios客户端的方法
		popCalendar();
	} 
	else {
		// 
	}
}

Date.prototype.format = function(format) {
	var date = {
		"M+": this.getMonth() + 1,
		"d+": this.getDate(),
		"h+": this.getHours(),
		"m+": this.getMinutes(),
		"s+": this.getSeconds(),
		"q+": Math.floor((this.getMonth() + 3) / 3),
		"S+": this.getMilliseconds()
	};
	if (/(y+)/i.test(format)) {
		format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
	}
	for (var k in date) {
		if (new RegExp("(" + k + ")").test(format)) {
			format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
		}
	}
	return format;
};

function formatDate(date) {
	var d = new Date(date),
	month = '' + (d.getMonth() + 1),
	day = '' + d.getDate(),
	year = d.getFullYear();
 
	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;

	return [year, month, day].join('-');
}

function validateNum(obj, ilen) {
	if (event.keyCode == 35 || event.keyCode == 36 || event.keyCode == 37 || event.keyCode == 39) {
		return false;
	}
	obj.val(obj.val().replace(/[^\d.]/g,""));   //先把非数字的都替换掉，除了数字和. 
	obj.val(obj.val().replace(/^\./g,""));      //必须保证第一个为数字而不是. 
	obj.val(obj.val().replace(/\.{2,}/g,"."));  //保证只有出现一个.而没有多个. 
	obj.val(obj.val().replace(".","$#$").replace(/\./g,"").replace("$#$",".")); //保证.只出现一次，而不能出现两次以上 
	if (obj.val().indexOf('.') != -1) {
		obj.val(obj.val().substring(0,obj.val().indexOf('.')+2));
	}
	else {
		 obj.val(obj.val().substring(0,ilen)); 
	}
	return true;
}

function getRadioValue(obj) {
	var len = obj.length;
	for(var i = 0; i < len; i++){
		if(obj[i].checked){
			return obj[i].value;
		}
	}
	return "";
}
function setRadioChecked(obj, value) {
	var len = obj.length;
	for(var i = 0; i < len; i++) {
		if(obj[i].value == value) {
			obj[i].checked = true;
			break;
		}
	}
}

function hideDiv(id) {
	$('#'+id).css('display', 'none');
}
function showDiv(id) {
	$('#'+id).css('display', 'block');
}
