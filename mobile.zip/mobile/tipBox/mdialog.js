/*  
 * @弹出提示层 ( 简单文字(simple) )  
 * @method  tipBox  
 * @description 默认配置参数   
 * @time    2017-11-13   
 * @param {Number} width -宽度  
 * @param {Number} height -高度         
 * @param {String} content -提示内容  
 * @param {Object} windowDom -载入窗口 默认当前窗口  
 * @param {Number} setTime -定时消失(毫秒) 默认为0 不消失  
 * @param {Boolean} hasMask -是否显示遮罩  
 * @param {Boolean} hasMaskWhite -显示白色遮罩   
 * @param {Boolean} clickDomCancel -点击空白取消  
 * @param {Function} confirm -回调函数(点击确认按钮的回调函数)  
 * @param {Function} cancel -回调函数(点击取消按钮的回调函数)  
 * @param {Boolean} hasBtn -显示按钮  
 * @param {String} type -动画类型 (简单文字,提示)  
 * @example   
 * new TipBox();   
 * new TipBox({content:'测试数据',confirm:function(){ alert('simple') }});   
*/  
function TipBox(str,cfg){  
    this.config = {   
        width          : 250,      
        height         : 170,                 
        content        : str,       
        windowDom      : window,   
        setTime        : 2000,     
        hasMask        : true,    
        hasMaskWhite   : true,   
        clickDomCancel : true,    
        confirm        : null, 
        cancel         : null, 
        hasBtn         : false,
        type           : 'simple'  
    }  
    $.extend(this.config,cfg);    
      
    //存在就retrun  
    if(TipBox.prototype.boundingBox) return;  
      
    //初始化  
    this.render(this.config.type);    
    return this;   
};  
  
//外层box  
TipBox.prototype.boundingBox = null;  
  
//渲染  
TipBox.prototype.render = function(tipType,container){    
    this.renderUI(tipType);   
      
    //绑定事件  
    this.bindUI();   
      
    //初始化UI  
    this.syncUI();   
    $(container || this.config.windowDom.document.body).append(TipBox.prototype.boundingBox);     
};  
  
//渲染UI  
TipBox.prototype.renderUI = function(tipType){   
    TipBox.prototype.boundingBox = $("<div id='animationTipBox'></div>");  
    if(this.config.hasBtn){
    	this.simpleRenderUI();  
    }else{
    	var simple ="<div class='dec_txt'>"+this.config.content+"</div>";  
    	TipBox.prototype.boundingBox.append(simple);  
    }
    TipBox.prototype.boundingBox.appendTo(this.config.windowDom.document.body);  
                  
    //是否显示遮罩  
    if(this.config.hasMask){  
        this._mask = $("<div class='mask'></div>"); 
        this._mask.appendTo(this.config.windowDom.document.body);  
        if(this.config.hasMaskWhite){//白色遮罩,去掉遮罩颜色
        	$(".mask").css("background-color","inherit");
        }
    }     
    // 是否显示按钮
    if(this.config.hasBtn){
    	if(this.config.type=='simple'){
    		this.config.height = 150;
    		this.config.width = 300;
    	}else{
    		 this.config.height = 206;
    	}
    	_this = this; 
        if(this.config.type=='simple'){
            	$(".simple").after("<button class='cancelButton'>取消</button><button class='okoButton'>确定</button>");
            	if(_this.config.content.length<18){
            		$(".simple").css("margin-top","35px");
                	$('button.cancelButton').css("margin-top","20px");
            	}else if(_this.config.content.length>=35){
            		$(".simple").css("margin-top","15px");
                	$('button.cancelButton').css("margin-top","40px");
            	}else{
            		$(".simple").css("margin-top","25px");
                	$('button.cancelButton').css("margin-top","30px");
            	}
        }
    }else{
    	$(".dec_txt").css("background-color","#E0E0E0");
    	$(".dec_txt").css("margin","5px");
    	$(".dec_txt").css("text-align","center");
    	$(".dec_txt").css("border-radius","5px");
    	var len = this.config.content.length;
		if(len<18){
			var w = len*25;
			var h = 20;
			var m = parseInt((300-w)/2);
			this.config.height = h;
			this.config.width = w;
    		$(".animationTipBox").css("margin-left",m+"px");
    		$(".animationTipBox").css("margin-right",m+"px");
    		$(".animationTipBox").css("height",h+"px");
    		$(".animationTipBox").css("width",w+"px");
    		$(".dec_txt").css("height",h+"px");
    	}else{
    		var w = 250;
    		var h = (parseInt(len/18)+1)*22;
    		this.config.height = h;
			this.config.width = w;
    		$(".animationTipBox").css("margin-left","20px");
    		$(".animationTipBox").css("margin-right","20px");
    		$(".animationTipBox").css("height",h+"px");
    		$(".animationTipBox").css("width",w+"px");
    		$(".dec_txt").css("height",h+"px");
    	}
    }
};  
  
TipBox.prototype.bindUI = function(){  
    _this = this;             
      
    //点击空白立即取消  
    this.config.clickDomCancel && this._mask && this._mask.click(function(){_this.close();});  
    
    if(this.config.hasBtn){
    	//点击cancel按钮立即取消  
        $('button.cancelButton').click(function(){
        	_this.close();
        	typeof _this.config.cancel === "function" && _this.config.cancel();
        });  
      　　　//点击ok按钮继续后续操作 
        $('button.okoButton').click(function(){
        	_this.close();
        	typeof _this.config.confirm === "function" && _this.config.confirm();
        });  
    }else{
    	//定时消失    
	    this.config.setTime && setTimeout( function(){ _this.close(); }, _this.config.setTime ); 
    }
};  
TipBox.prototype.syncUI = function(){             
    TipBox.prototype.boundingBox.css({  
        width       : this.config.width+'px',  
        height      : this.config.height+'px',  
        marginLeft  : "-"+(this.config.width/2)+'px',  
        marginTop   : "-"+(this.config.height/2)+'px'  
    }); 
    
    
    //$('button.okoButton').on('click',function(){_this.close();});
};  
  
//简单文字效果
TipBox.prototype.simpleRenderUI = function(){  
    var simple = "<div class='simple'>";  
    	simple +="     <div class='title'>提示</div>";  
    	simple +="     <div class='dec_txt'>"+this.config.content+"</div>";  
    	simple +="</div>";  
    TipBox.prototype.boundingBox.append(simple);  
};  

//关闭  
TipBox.prototype.close = function(){      
    TipBox.prototype.destroy();  
    this.destroy();  
};  
  
//销毁  
TipBox.prototype.destroy = function(){  
    this._mask && this._mask.remove();  
    TipBox.prototype.boundingBox && TipBox.prototype.boundingBox.remove();   
    TipBox.prototype.boundingBox = null;  
};  