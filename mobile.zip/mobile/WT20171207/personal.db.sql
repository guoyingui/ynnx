create or replace view v_cdm_calendar as
select caldate caldate,workflag from(select row_number() 
  over (partition by a.caldate order by a.modifydate desc) lev,
  a.* from wbs_calendar a where a.projectid=-1)
where lev = 1;